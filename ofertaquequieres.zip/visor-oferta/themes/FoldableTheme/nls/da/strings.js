﻿define(
   ({
    _themeLabel: "Foldbart tema",
    _layout_default: "Standardlayout",
    _layout_layout1: "Layout 1"
  })
);