﻿define(
   ({
    _themeLabel: "Katlanabilir Tema",
    _layout_default: "Varsayılan Düzen",
    _layout_layout1: "Düzen 1"
  })
);