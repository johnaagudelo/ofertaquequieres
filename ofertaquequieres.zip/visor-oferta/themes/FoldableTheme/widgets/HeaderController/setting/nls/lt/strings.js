﻿define(
   ({
    group: "Pavadinimas",
    openAll: "Atidaryti viską skydelyje",
    dropDown: "Rodyti išskleidžiamame meniu",
    noGroup: "Nėra nustatytų valdiklių grupių.",
    groupSetLabel: "Nustatyti valdiklių grupių savybes"
  })
);