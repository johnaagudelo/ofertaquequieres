﻿define(
   ({
    group: "Naam",
    openAll: "Alles openen in deelvenster",
    dropDown: "Weergeven in vervolgkeuzemenu",
    noGroup: "Er is geen groep met widgets ingesteld.",
    groupSetLabel: "Eigenschappen voor groepen van widgets instellen"
  })
);