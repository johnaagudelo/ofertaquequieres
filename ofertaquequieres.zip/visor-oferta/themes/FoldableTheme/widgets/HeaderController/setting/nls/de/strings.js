﻿define(
   ({
    group: "Name",
    openAll: "Alle im Fenster öffnen",
    dropDown: "In Dropdown-Menü anzeigen",
    noGroup: "Es wurde keine Widget-Gruppe festgelegt.",
    groupSetLabel: "Eigenschaften für Widget-Gruppen festlegen"
  })
);