﻿define(
   ({
    _widgetLabel: "Kontroler nagłówka",
    signin: "Zaloguj się",
    signout: "Wyloguj się",
    about: "Informacje o",
    signInTo: "Zaloguj się do",
    cantSignOutTip: "Funkcja nie ma zastosowania w widoku podglądu."
  })
);
