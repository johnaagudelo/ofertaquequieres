﻿define(
   ({
    labelBookmarkName: "Aktuelle Ansicht als Lesezeichen speichern",
    labelPlay: "Alle wiedergeben",
    labelStop: "Beenden",
    labelDelete: "Löschen",
    placeholderBookmarkName: "Lesezeichenname",
    errorNameExist: "Lesezeichen ist vorhanden!",
    errorNameNull: "Ungültiger Lesezeichenname!",
    _widgetLabel: "Lesezeichen"
  })
);