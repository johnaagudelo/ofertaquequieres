﻿define(
   ({
    labelBookmarkName: "الإشارة المرجعية للعرض الحالي",
    labelPlay: "تشغيل الكل",
    labelStop: "إيقاف",
    labelDelete: "حذف",
    placeholderBookmarkName: "اسم الإشارة المرجعية",
    errorNameExist: "الإشارات المرجعية موجودة!",
    errorNameNull: "اسم إشارة مرجعية غير صحيح!",
    _widgetLabel: "علامة مرجعية"
  })
);