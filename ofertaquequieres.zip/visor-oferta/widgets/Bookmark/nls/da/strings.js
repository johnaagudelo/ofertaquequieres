﻿define(
   ({
    labelBookmarkName: "Sæt bogmærke ved den aktuelle visning",
    labelPlay: "Afspil alle",
    labelStop: "Stop",
    labelDelete: "Slet",
    placeholderBookmarkName: "Bogmærkenavn",
    errorNameExist: "Bogmærket findes!",
    errorNameNull: "Ugyldigt bogmærkenavn!",
    _widgetLabel: "Bogmærke"
  })
);