﻿define(
   ({
    _widgetLabel: "Galerie podkladových map"
  })
);