﻿define(
   ({
    _widgetLabel: "ベースマップ ギャラリー"
  })
);