﻿define(
   ({
    _widgetLabel: "Bakgrunnskartgalleri"
  })
);