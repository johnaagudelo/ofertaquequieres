﻿define(
   ({
    _widgetLabel: "底图库"
  })
);