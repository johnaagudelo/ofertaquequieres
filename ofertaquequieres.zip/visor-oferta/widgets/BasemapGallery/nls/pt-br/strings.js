﻿define(
   ({
    _widgetLabel: "Galeria de Mapa Base"
  })
);