﻿define(
   ({
    _widgetLabel: "Bộ sưu tập bản đồ nền"
  })
);