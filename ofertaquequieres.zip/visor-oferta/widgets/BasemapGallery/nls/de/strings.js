﻿define(
   ({
    _widgetLabel: "Grundkarten-Galerie"
  })
);